﻿// Project.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>

int main()
{
    std::cout << "Hello World!\n";
	int a,b,c;
	std::cin >> a >> b;
	c = a + b;
	std::cout << c;
}

